#include "controller.h"
#include "opResizeDown.h"

opResizeDown::opResizeDown(controller* pCont) :operation(pCont) {}

opResizeDown::~opResizeDown()
{
}
void opResizeDown::Execute()
{
	Graph* pGraph = pControl->getGraph();
	shape* ShapeSelected = pGraph->get_selected_shape();
	ShapeSelected->Resize(0.5);
}
