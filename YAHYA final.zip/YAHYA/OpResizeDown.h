#pragma once
#include "Operations/operation.h"
class opResizeDown :public operation
{
public:
	opResizeDown(controller* pCont);

	virtual ~opResizeDown();

	//Add rectangle to the controller
	virtual void Execute();
};


