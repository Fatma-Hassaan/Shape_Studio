#pragma once
#include "Operations/operation.h"
class opResizeUP :public operation
{
public:
	opResizeUP(controller* pCont);

	virtual ~opResizeUP();

	//Add rectangle to the controller
	virtual void Execute();
};

