#include "controller.h"
#include "opResizeUp.h"

opResizeUP::opResizeUP(controller* pCont) :operation(pCont) {}

opResizeUP::~opResizeUP()
{
}
void opResizeUP::Execute()
{
	Graph* pGraph = pControl->getGraph();
	shape* ShapeSelected = pGraph->get_selected_shape();
	ShapeSelected->Resize(2);
}