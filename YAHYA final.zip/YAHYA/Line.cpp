#include "Line.h"

Line::Line(Point P1, Point P2, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
}

Line::~Line()
{

}

void Line::Draw(GUI* pUI) const
{
	
	//Call Output::DrawLine to draw a Lineangle on the screen	
	pUI->DrawLine(Corner1, Corner2, ShpGfxInfo);

}

void Line::Resize(double Size)
{
    Point Center;
    Center.x = (Corner1.x + Corner2.x) / 2;
    Center.y = (Corner1.y + Corner2.y) / 2;
    ///////translation to the origan///////
    Corner1.x -= Center.x;
    Corner2.x -= Center.x;
    Corner1.y -= Center.y;
    Corner2.y -= Center.y;
    ///////Resize stage/////
    Corner1.x *= Size;
    Corner2.x *= Size;
    Corner1.y *= Size;
    Corner2.y *= Size;
    ////////translation back to the point  //////
    Corner1.x += Center.x;
    Corner2.x += Center.x;
    Corner1.y += Center.y;
    Corner2.y += Center.y;
}

void Line::Rotate()
{
    Point Center;
    Center.x = (Corner1.x + Corner2.x) / 2;
    Center.y = (Corner1.y + Corner2.y) / 2;
    //////translation to the origan///////
    Corner1.x -= Center.x;
    Corner2.x -= Center.x;
    Corner1.y -= Center.y;
    Corner2.y -= Center.y;
    ///////rotation stage/////
    Point Temp;
    Temp = Corner1;
    Corner1.x = -Temp.y;
    Corner1.y = Temp.x;
    Temp = Corner2;
    Corner2.x = -Temp.y;
    Corner2.y = Temp.x;
    ////////translation back to the point //////
    Corner1.x += Center.x;
    Corner2.x += Center.x;
    Corner1.y += Center.y;
    Corner2.y += Center.y;
}
