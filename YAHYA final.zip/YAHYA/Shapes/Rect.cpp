#include "Rect.h"

Rect::Rect(Point P1, Point P2, GfxInfo shapeGfxInfo):shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
}

Rect::~Rect()
{

}

void Rect::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pUI->DrawRect(Corner1, Corner2, ShpGfxInfo);
}

void Rect::Resize(double Size)
{
	Point Center;
	Center.x = (Corner1.x + Corner2.x) / 2;
	Center.y = (Corner1.y + Corner2.y) / 2;
	///////translation to the origan///////
	Corner1.x -= Center.x;
	Corner2.x -= Center.x;
	Corner1.y -= Center.y;
	Corner2.y -= Center.y;
	///////Resize stage/////
	Corner1.x *= Size;
	Corner2.x *= Size;
	Corner1.y *= Size;
	Corner2.y *= Size;
	////////translation back to the point //////
	Corner1.x += Center.x;
	Corner2.x += Center.x;
	Corner1.y += Center.y;
	Corner2.y += Center.y;
}

void Rect::Rotate()
{
	Point Center;
	Center.x = (Corner1.x + Corner2.x) / 2;
	Center.y = (Corner1.y + Corner2.y) / 2;
	//////translation to the origan///////
	Corner1.x -= Center.x;
	Corner2.x -= Center.x;
	Corner1.y -= Center.y;
	Corner2.y -= Center.y;
	///////rotation stage/////
	Point Temp;
	Temp = Corner1;
	Corner1.x = -Temp.y;
	Corner1.y = Temp.x;
	Temp = Corner2;
	Corner2.x = -Temp.y;
	Corner2.y = Temp.x;
	////////translation back //////
	Corner1.x += Center.x;
	Corner2.x += Center.x;
	Corner1.y += Center.y;
	Corner2.y += Center.y;
}
