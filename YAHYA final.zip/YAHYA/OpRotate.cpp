#include "opRotate.h"
#include"controller.h"

opRotate::opRotate(controller* pCont) :operation(pCont)
{
}

opRotate::~opRotate()
{
}

void opRotate::Execute()
{
	Graph* pGraph = pControl->getGraph();
	shape* activeShape = pGraph->get_selected_shape();
	activeShape->Rotate();
}
