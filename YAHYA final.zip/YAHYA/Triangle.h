#pragma once

#include "Shapes/shape.h"

class Triangle : public shape
{
private:
	Point Corner1;
	Point Corner2;
public:
	Triangle(Point, Point, GfxInfo shapeGfxInfo);
	virtual ~Triangle();
	virtual void Draw(GUI* pUI) const;
	virtual void Resize(double Size)override;
	virtual void Rotate()override;
};

