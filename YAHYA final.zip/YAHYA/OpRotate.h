#pragma once
#include "Operations/operation.h"
class opRotate :public operation
{
public:
	opRotate(controller* pCont);

	virtual ~opRotate();

	//Add rectangle to the controller
	virtual void Execute();
};

