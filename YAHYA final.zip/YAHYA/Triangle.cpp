#include "Triangle.h"

Triangle::Triangle(Point P1, Point P2, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
}

Triangle::~Triangle()
{

}

void Triangle::Draw(GUI* pUI) const
{
	//Call Output::DrawTriangle to draw a Triangle on the screen	
	pUI->DrawTriangle(Corner1, Corner2, ShpGfxInfo);
}

void Triangle::Resize(double Size)
{
    Point Center;
    Center.x = (Corner1.x + Corner2.x) / 2;
    Center.y = (Corner1.y + Corner2.y) / 2;
    ///////translation to the origan///////
    Corner1.x -= Center.x;
    Corner2.x -= Center.x;
    Corner1.y -= Center.y;
    Corner2.y -= Center.y;
    ///////Resize stage/////
    Corner1.x *= Size;
    Corner2.x *= Size;
    Corner1.y *= Size;
    Corner2.y *= Size;
    ////////translation back to the point  //////
    Corner1.x += Center.x;
    Corner2.x += Center.x;
    Corner1.y += Center.y;
    Corner2.y += Center.y;
}

void Triangle::Rotate()
{
}
